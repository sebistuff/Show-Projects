## Readme - M3

* Gruppe: 3
* Team-Nr.: 208
* Projektthema: LearnEasy

### Implementierung

Framework: Android

API-Version: 31

Geräte, auf denen getestet wurde:
- Pixel 6 Emulator
- Samsung Galaxy S20FE (eigenes Handy)

Externe Libraries und Frameworks:
keine

Dauer der Entwicklung:
40-50h

Weitere Anmerkungen:
- Die Profilavatare wurden mit [Canva](https://www.canva.com/de_de/) erstellt

